package com.tnsif.constructor;

public class ConstructorOverloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee obj1 = new Employee(1);
		Employee obj2 = new Employee(2, "Anil");
		Employee obj3 = new Employee(3, "kumar", 50000);
		obj1.show();
		obj2.show();
		obj3.show();
	}

}
