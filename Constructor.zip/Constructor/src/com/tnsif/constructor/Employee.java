package com.tnsif.constructor;

public class Employee {
	String name;
	int employeeId , salary;
	
	Employee(int EId) {
		employeeId = EId;
	}
	
	Employee(int EId, String S) {
		employeeId = EId;
		name = S;
	}
	
	Employee(int EId, String S, int Sal) {
		employeeId = EId;
		name = S;
		salary = Sal;
	}
	
	public void show() {
		System.out.println(employeeId + " " + name +" "+salary);
	}
}
