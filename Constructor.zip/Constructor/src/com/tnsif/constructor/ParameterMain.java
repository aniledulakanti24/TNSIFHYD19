package com.tnsif.constructor;

public class ParameterMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParameterConstructor obj = new ParameterConstructor("Anil Kumar", 21, "Dandumailaram", 147852369);
		obj.run();
	}

}
