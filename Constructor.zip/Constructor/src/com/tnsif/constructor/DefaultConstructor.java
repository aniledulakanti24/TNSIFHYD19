package com.tnsif.constructor;

public class DefaultConstructor {
	private String name;
	private int age ;
	private String address;
	private int mobilenumber;
	DefaultConstructor() 
	{
		name = "Anil Kumar";
		age = 21;
		address = "Dandumailaram";
		mobilenumber = 147852369;
	}
	public void run() {
		if(name == "Anil Kumar" &&
		age == 21 &&
		address == "Dandumailaram" &&
		mobilenumber == 147852369) {
			System.out.println("Valid Information");
		} else {
			System.out.println("Invalid Information");
		}
	}
}
