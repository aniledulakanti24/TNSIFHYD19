package com.tnsif.constructor;

public class ParameterConstructor {
	private String name;
	private int age ;
	private String address;
	private int mobilenumber;
	
	ParameterConstructor(String name, int age, String address, int mobilenumber) 
	{
		this.name = name;
		this.age = age;
		this.address = address;
		this.mobilenumber = mobilenumber;
	}
	
	public void run() {
		if(this.name == "Anil Kumar" &&
		this.age == 21 &&
		this.address == "Dandumailaram" &&
		this.mobilenumber == 147852369) {
			System.out.println("Valid Information");
		} else {
			System.out.println("Invalid Information");
		}
	}
}
