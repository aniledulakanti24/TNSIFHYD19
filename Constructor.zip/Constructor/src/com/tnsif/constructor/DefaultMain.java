package com.tnsif.constructor;

public class DefaultMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultConstructor obj = new DefaultConstructor();
		obj.run();
	}

}
