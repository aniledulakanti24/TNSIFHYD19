/**
 * 
 */
/**
 * 
 */
module typeCastingandPrimitiveDataType {
}