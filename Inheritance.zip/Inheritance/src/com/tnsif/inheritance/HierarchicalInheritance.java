package com.tnsif.inheritance;

public class HierarchicalInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog2 dog = new Dog2();
		Cat cat = new Cat();
		dog.eat();
		dog.bark();
		cat.eat();
		cat.meow();
	}

}
