package com.tnsif.inheritance;

public class SingleInheritance {
	public static void main(String[] args) {
		Dog obj = new Dog();
		obj.eat();
		obj.bark();
	}
	
}
