package com.tnsif.inheritance;

public class Animal3 {
	public void eat() {
		System.out.println("eating");
	}
}

class Dog2 extends Animal3 {
	public void bark() {
		System.out.println("barking");
	}
}

class Cat extends Animal3 {
	public void meow() {
		System.out.println("meowing");
	}
}