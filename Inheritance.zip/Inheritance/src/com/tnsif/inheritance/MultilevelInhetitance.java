package com.tnsif.inheritance;

public class MultilevelInhetitance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BabyDog obj = new BabyDog();
		obj.eat();
		obj.bark();
		obj.weep();
	}

}
