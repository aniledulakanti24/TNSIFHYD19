package com.tnsif.polymorphism;

public class methodOverriding {
	public void show() {
		System.out.println("Inside Parent Class");
	}
}
class SubClass1 extends methodOverriding {
	public void show() {
		System.out.println("Inside SubClass1 Class");
	}
}

class SubClass2 extends methodOverriding {
	public void show() {
		System.out.println("Inside SubClass2 Class");
	}
}