package com.tnsif.polymorphism;

public class MethodOverloadingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methodOverloading obj = new methodOverloading();
		int productoftwonumbers = obj.multiply(10,20);
		int productofthreenumbers = obj.multiply(10,20, 30);
		System.out.println(productoftwonumbers);
		System.out.println(productofthreenumbers);
	}

}
