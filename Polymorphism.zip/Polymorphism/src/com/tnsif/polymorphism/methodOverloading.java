package com.tnsif.polymorphism;

public class methodOverloading {
	public int multiply(int num1, int num2) {
		return num1 * num2;
	}
	public int multiply(int num1, int num2, int num3) {
		return num1 * num2 * num3;
	}
}
