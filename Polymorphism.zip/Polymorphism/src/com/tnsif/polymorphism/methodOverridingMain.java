package com.tnsif.polymorphism;

public class methodOverridingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methodOverriding obj ;
		obj = new SubClass1();
		obj.show();
		obj = new SubClass2();
		obj.show();
	}

}
