package com.tnsif.builtinpackages;

import java.util.*;

public class UtilPackage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int num = sc.nextInt();
		sc.close();
		
		Date date = new Date();
		
		ArrayList<String> names = new ArrayList<>();
        names.add("Anil");
        names.add("Kumar");
        names.add("Edulakanti");
		
		
		//printing the results
		System.out.println("The Number is :" + num);
		System.out.println("Current Date: " + date);
		System.out.println("First Name: " + names.get(0));
		for (String name : names) {
            System.out.println(name);
        }
	}

}
