package com.tnsif.builtinpackages;

import java.lang.*;

public class LangPackage {
	public static void main(String[] args) {
        
        Byte by = new Byte("0001");
        Integer integer = new Integer("10");
        Long l = new Long("1000000");
        Float fl = new Float("1.1");
        Double doub = new Double("1.25");
        Character character = new Character('a');
       // String string = new String('Anil');
        Boolean bool = new Boolean("False");
        
        //printing result
        System.out.println("MilliSeconds: " + System.currentTimeMillis());
        System.out.println("");
        System.out.println("Byte: " + by);
        System.out.println("Integer: " + integer);
        System.out.println("Long: " + l);
        System.out.println("Float: " + fl);
        System.out.println("Double: " + doub);
        System.out.println("Character: " + character);
        //System.out.println("String: " + string);
        System.out.println("Boolean: " + bool);
	}
}
