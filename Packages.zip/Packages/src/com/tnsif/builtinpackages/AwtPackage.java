//package com.tnsif.builtinpackages;
//
//import java.awt.*;
//
//public class AwtPackage {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		// Creating a Frame
//        Frame frame = new Frame("My First Frame");
//        
//        // Setting size and visibility
//        frame.setSize(400, 300);
//        frame.setVisible(true);
//        
//        //Frame frame = new Frame("Button Example");
//        
//        // Creating a Button
//        Button button = new Button("Click Me");
//        
//        // Adding Button to Frame
//        frame.add(button);
//        
//        // Setting size and visibility
//        frame.setSize(200, 100);
//        frame.setVisible(true);
//	}
//
//}
