package com.tnsif.userdefinedpackage;

public class Asia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		India indiaobj = new India();
		China chinaobj = new China();
		Indonesia indonesiaobj = new Indonesia();
		System.out.println(indiaobj.MalePopulation());
		System.out.println(indiaobj.FemalePopulation());
		System.out.println(indiaobj.population());
		System.out.println("");
		System.out.println(chinaobj.MalePopulation());
		System.out.println(chinaobj.FemalePopulation());
		System.out.println(chinaobj.population());
		System.out.println("");
		System.out.println(indonesiaobj.MalePopulation());
		System.out.println(indonesiaobj.FemalePopulation());
		System.out.println(indonesiaobj.population());
	}

}
