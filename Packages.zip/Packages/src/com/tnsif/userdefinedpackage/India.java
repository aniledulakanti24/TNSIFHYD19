package com.tnsif.userdefinedpackage;

public class India {
	public String MalePopulation() {
		return "India MalePopulation is Approximately 713 million";
	}
	
	public String FemalePopulation() {
		return "India FemalePopulation is Approximately 679 million";
	}
	
	public String population() {
		return "India population is Approximately 1.392 billion";
	}
}

class China {
	public String MalePopulation() {
		return "China MalePopulation is Approximately 685  million";
	}
	
	public String FemalePopulation() {
		return "China FemalePopulation is Approximately 660  million";
	}
	
	public String population() {
		return "China population is Approximately 1.345 billion";
	}
}
class Indonesia {
	public String MalePopulation() {
		return "Indonesia MalePopulation is Approximately 133  million";
	}
	
	public String FemalePopulation() {
		return "Indonesia FemalePopulation is Approximately 132  million";
	}
	
	public String population() {
		return "Indonesia population is Approximately 265 million";
	}
}