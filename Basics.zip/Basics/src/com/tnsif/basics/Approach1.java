package com.tnsif.basics;

public class Approach1 {
	int emp_id = 69;
	 static String emp_name = "Anil";
	 public static void main(String[] args) {
		int emp_salary = 30000;
		Approach1 obj = new Approach1();
		System.out.println(obj.emp_id);
		System.out.println(Approach1.emp_name);
		System.out.println(emp_name);
		System.out.println(emp_salary);
	}
}
//https://github.com/aniledulakanti24/TNSIFHYD19.git