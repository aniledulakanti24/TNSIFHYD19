package com.tnsif.basics;

class NormalClass {
	String batsman = "Virat Kohli";
	void display() {
		System.out.println("RCB");
	}
	static String bowler = "Siraj";
	static String display1() {
		return "RCB WON";
	}
}

public class Approach2 {
	public static void main(String[] args) {
		NormalClass obj = new NormalClass();
		System.out.println(obj.batsman);
		obj.display();
		System.out.println(NormalClass.bowler);
		System.out.println(NormalClass.display1());
		
	}
}
