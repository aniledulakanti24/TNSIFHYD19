package com.tnsif.Super;

public class Person {
	void message() {
		System.out.println("This is base class method");
	}
}

class Student extends Person {
	void message() {
		System.out.println("This is sub class method");
	}
	
	void display() {
		message();
		super.message();
	}
}