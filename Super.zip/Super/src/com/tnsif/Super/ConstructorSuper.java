package com.tnsif.Super;

public class ConstructorSuper {
	ConstructorSuper() {
		System.out.println("Parent class constructor");
	}
}

class Subclass extends ConstructorSuper {
	Subclass(){
		super();
		System.out.println("Child class constructor");
	}	
}
