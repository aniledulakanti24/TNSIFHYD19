package com.tnsif.Super;

public class ConstructorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Subclass obj = new Subclass();
	}

}
