package com.tnsif.Super;

public class MethodMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student obj = new Student();
		obj.display();
	}

}
