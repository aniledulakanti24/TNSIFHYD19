package com.tnsif.Super;

public class VariableMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		splendor obj = new splendor();
		obj.show();
	}

}
