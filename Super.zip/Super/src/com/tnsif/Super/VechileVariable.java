package com.tnsif.Super;

public class VechileVariable {
	int maxSpeed = 120;
}
class splendor extends VechileVariable {
	int maxSpeed = 150;
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("maxSpeed: " + super.maxSpeed);
	}
}
