/**
 * 
 */
/**
 * 
 */
module CrudProjectSriIndu {
	requires java.sql;
}