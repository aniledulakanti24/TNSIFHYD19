package com.tnsif.instanceandstaticmembers;

public class InstanceMembersNormalClass {
	String name = "Anil";
	int batch = 19;
	
	void display () {
		System.out.println(name);
		System.out.println(batch);
	}
	
	String friend(String name) {
		return "my friend name is : "+ name ;
	}
}
