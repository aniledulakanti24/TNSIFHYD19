package com.tnsif.instanceandstaticmembers;

public class StaticMembersNormalClass {
	static String name = "Anil";
	static int batch = 19;
	
	static void display() {
		System.out.println(name);
		System.out.println(batch);
	}
	
	static String friend(String name) {
		return "your friend name is: "+name;
	}
}
