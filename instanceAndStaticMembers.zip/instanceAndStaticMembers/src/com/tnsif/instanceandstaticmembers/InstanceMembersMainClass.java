package com.tnsif.instanceandstaticmembers;

public class InstanceMembersMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InstanceMembersNormalClass obj = new InstanceMembersNormalClass();
		obj.display();
		System.out.println(obj.friend("vinay"));
	}

}
s