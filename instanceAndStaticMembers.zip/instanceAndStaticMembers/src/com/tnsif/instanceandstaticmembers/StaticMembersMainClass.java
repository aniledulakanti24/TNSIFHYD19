package com.tnsif.instanceandstaticmembers;

public class StaticMembersMainClass {
	
	static String age(int age) {
		return "Your age is : "+age;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticMembersNormalClass.display();
		System.out.println(StaticMembersNormalClass.friend("vinay"));
		System.out.println(age(21));
	}

}
