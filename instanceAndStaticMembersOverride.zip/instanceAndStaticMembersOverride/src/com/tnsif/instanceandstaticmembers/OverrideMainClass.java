package com.tnsif.instanceandstaticmembers;

public class OverrideMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverrideNormalClass obj = new ChildClass();
		System.out.println(obj.username);
		System.out.println(obj.password);
		obj.instanceDisplay();
		obj.staticDisplay();
	}

}
