package com.tnsif.instanceandstaticmembers;

public class OverloadNormalClass {
		
		//Instance and Static Methods
		
		int instanceAdd(int a , int b) {
			return a + b;
		}
		
		static int staticMul(int a , int b) {
			return a * b;
		}
		
		
		//Instance and Static Methods
		
		double instanceAdd(double a, double b) {
			return a + b;
		}
		
		static double staticMul(double a, double b) {
			return a * b;
		}
}
