package com.tnsif.instanceandstaticmembers;

public class OverloadMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverloadNormalClass obj = new OverloadNormalClass();
		System.out.println(obj.instanceAdd(2,1));
		System.out.println(OverloadNormalClass.staticMul(2,1));
		System.out.println(obj.instanceAdd(2.1,1.1));
		System.out.println(OverloadNormalClass.staticMul(2.1,1.1));
	}

}
