package com.tnsif.instanceandstaticmembers;

public class OverrideNormalClass {
	//Instance and Static attributes
	String username = "ParentName";
	
	static String password = "parent@1234";
	
	//Instance and Static Methods
	
	void instanceDisplay() {
		System.out.println("ParentInstanceDisplay");
	}
	
	static void staticDisplay() {
		System.out.println("ParentStaticDisplay");
	}
}
class ChildClass extends OverrideNormalClass {
	String username = "ChildName";
	
	static String password = "child@1234";
	
	//Instance and Static Methods
	@Override
	void instanceDisplay() {
		System.out.println("ChildInstanceDisplay");
	}
	@Override
	static void staticDisplay() {
		System.out.println("ChildStaticDisplay");
	}
}
