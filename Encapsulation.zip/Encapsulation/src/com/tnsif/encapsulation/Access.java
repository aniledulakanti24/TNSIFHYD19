package com.tnsif.encapsulation;

public class Access {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NormalClass obj = new NormalClass();
		System.out.println(obj.Name);
		System.out.println(obj.Age);
		// System.out.println(obj.MobileNumber);
		// System.out.println(obj.UserName);
		// System.out.println(obj.Password);
	}

}
