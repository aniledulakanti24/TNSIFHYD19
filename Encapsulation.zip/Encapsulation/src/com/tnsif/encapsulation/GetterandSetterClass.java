package com.tnsif.encapsulation;

public class GetterandSetterClass {
	private int MobileNumber = 123456789; 
	private String UserName = "Anil1234";
	private String Password = "Anil@1234";
	public String Name = "Anil";
	public int Age = 21;
	
	public int getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(int mobileNumber) {
		MobileNumber = mobileNumber;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		this.UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	
}
