package com.tnsif.encapsulation;

public class NormalClass {
	private int MobileNumber = 123456789; 
	private String UserName = "Anil1234";
	private String Password = "Anil@1234";
	public String Name = "Anil";
	public int Age = 21;
}
