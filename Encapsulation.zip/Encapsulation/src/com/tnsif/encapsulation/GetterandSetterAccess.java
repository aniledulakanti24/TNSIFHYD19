package com.tnsif.encapsulation;

public class GetterandSetterAccess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetterandSetterClass obj = new GetterandSetterClass();
		System.out.println("The MobileNumber is : " + obj.getMobileNumber());
		obj.setMobileNumber(147852369);
		System.out.println("The Updated MobileNumber is : " + obj.getMobileNumber());
		System.out.println();
		System.out.println("The Username is : " + obj.getUserName());
		obj.setUserName("Anil99899");
		System.out.println("The Updated Username is : " + obj.getUserName());
		System.out.println();
		System.out.println("The Password is : " + obj.getPassword());
		obj.setPassword("Anil@99899");
		System.out.println("The Updated Password is : " + obj.getPassword());
	}

}
